﻿using System;

namespace System_Info_Founder_v1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("OS NAME: ");
            Console.WriteLine(System.Environment.OSVersion.Platform);
            Console.WriteLine();
            Console.WriteLine("SERVICE PACK: ");
            Console.WriteLine(System.Environment.OSVersion.ServicePack);
            Console.WriteLine();
            Console.WriteLine("VERSION: ");
            Console.WriteLine(System.Environment.OSVersion.Version);
            Console.WriteLine(System.Environment.OSVersion.VersionString);
            Console.WriteLine();
            Console.WriteLine("MACHINE NAME: ");
            Console.WriteLine(System.Environment.MachineName);
            Console.WriteLine();
            Console.WriteLine("CPU CORES: ");
            Console.WriteLine(System.Environment.ProcessorCount);
            Console.WriteLine();
            Console.WriteLine("USER: ");
            Console.WriteLine(System.Environment.UserName);
            Console.WriteLine();
            Console.WriteLine("SYSTEM DIRECTORY: ");
            Console.WriteLine(System.Environment.SystemDirectory);
            Console.ReadKey();
        }
    }
}
